<?php
require "conn.php";
$user_name = $_POST["user"];

$mysql_qry = "select * from tesis where username like '$user_name';";
$result = mysqli_query($conn, $mysql_qry);
if(mysqli_num_rows($result) > 0 ) {
echo "conecto" ;
}
else {
echo "usuario ya existente";
}

?>