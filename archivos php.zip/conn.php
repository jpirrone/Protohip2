<?php
$db_name = "pokemon";
$mysql_username = "root";
$mysql_password = "";
$mysql_name = "localhost";
$conn = mysqli_connect($mysql_name, $mysql_username, $mysql_password, $db_name);
?>