<?php
require "conn.php";
$username = $_POST["username"];
$password = $_POST["password"];
$imei = $_POST["imei"];

$mysql_qry = "insert into docdoc (username, password, imei) values ('$username','$password','$imei')";

if($conn->query($mysql_qry) === TRUE){
echo "Lo metiste";
}
else {
echo "Error: " . $mysql_qry . "<br>" . $conn->error;
}
$conn->close();
?>